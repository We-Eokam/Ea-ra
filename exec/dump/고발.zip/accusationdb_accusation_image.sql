-- MySQL dump 10.13  Distrib 5.7.38, for Win64 (x86_64)
--
-- Host: 3.35.137.30    Database: accusationdb
-- ------------------------------------------------------
-- Server version	11.1.2-MariaDB-1:11.1.2+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accusation_image`
--

DROP TABLE IF EXISTS `accusation_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accusation_image` (
  `accusation_accusation_id` bigint(20) DEFAULT NULL,
  `image_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_url` varchar(255) NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `FKtnowf8x5oas18urue2riufjum` (`accusation_accusation_id`),
  CONSTRAINT `FKtnowf8x5oas18urue2riufjum` FOREIGN KEY (`accusation_accusation_id`) REFERENCES `accusation` (`accusation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accusation_image`
--

LOCK TABLES `accusation_image` WRITE;
/*!40000 ALTER TABLE `accusation_image` DISABLE KEYS */;
INSERT INTO `accusation_image` VALUES (1,1,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-1243922_%EB%82%98.PNG'),(2,2,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-1323360_%EB%8D%94%EC%9B%8C.PNG'),(3,3,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2000025_%EB%8D%94%EC%9B%8C.PNG'),(4,4,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2001077_%EB%8D%94%EC%9B%8C.PNG'),(5,5,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2001867_%EB%8D%94%EC%9B%8C.PNG'),(6,6,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2657020_'),(7,7,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2715045_'),(8,8,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2724994_'),(9,9,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2730279_'),(10,10,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-2746072_'),(11,11,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3502377_maxresdefault.jpg'),(12,12,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3504007_maxresdefault.jpg'),(13,13,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3505068_maxresdefault.jpg'),(14,14,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3506067_maxresdefault.jpg'),(15,15,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3506917_maxresdefault.jpg'),(16,16,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3507860_maxresdefault.jpg'),(17,17,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3508632_maxresdefault.jpg'),(18,18,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3509353_maxresdefault.jpg'),(19,19,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3510125_maxresdefault.jpg'),(20,20,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3510901_maxresdefault.jpg'),(21,21,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3511580_maxresdefault.jpg'),(22,22,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3512303_maxresdefault.jpg'),(23,23,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3512939_maxresdefault.jpg'),(24,24,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3513557_maxresdefault.jpg'),(25,25,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3514294_maxresdefault.jpg'),(26,26,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3514806_maxresdefault.jpg'),(27,27,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3515460_maxresdefault.jpg'),(28,28,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3515957_maxresdefault.jpg'),(29,29,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3516567_maxresdefault.jpg'),(30,30,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3517178_maxresdefault.jpg'),(31,31,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3517680_maxresdefault.jpg'),(32,32,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3518362_maxresdefault.jpg'),(33,33,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-08-3518913_maxresdefault.jpg'),(34,34,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-15-5518995_4905b26e6.png'),(35,35,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-16-1217252_4905b26e6.png'),(36,36,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-16-1220084_4905b26e6.png'),(37,37,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-14-16-1220903_4905b26e6.png'),(38,38,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-00-3402234_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(39,39,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-00-4202006_'),(40,40,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-00-4220142_'),(41,41,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-00-4934048_'),(42,42,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-2057119_blob'),(43,43,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-2622107_blob'),(44,44,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-2850835_blob'),(45,45,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-2854540_blob'),(46,46,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-3039162_blob'),(47,47,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-03-3208956_blob'),(48,48,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-04-0451452_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(49,49,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-04-0714286_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(50,50,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-04-1308480_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(51,51,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-04-2820504_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(52,52,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-04-3413033_%EB%8B%B9%EA%B7%BC%EB%A1%9C%EA%B3%A0.PNG'),(53,53,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-06-2636634_i15791942193.jpg'),(54,54,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-09-1206223_i15791942193.jpg'),(55,55,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-09-2911364_images.jfif'),(56,56,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-15-09-3022874_images.jfif'),(57,57,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-05-4927480_blob'),(58,58,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-05-4936267_blob'),(59,59,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-05-5127931_blob'),(60,60,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-08-0953848_blob'),(61,61,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-08-1300898_blob'),(62,62,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-08-1307083_blob'),(63,63,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-08-1836562_blob'),(64,64,'https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023-11-16-15-0723514_blob');
/*!40000 ALTER TABLE `accusation_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17  0:07:45
