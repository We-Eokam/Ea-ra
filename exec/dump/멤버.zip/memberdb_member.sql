-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 3.35.137.30    Database: memberdb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `bill` int DEFAULT NULL,
  `bill_count` int DEFAULT NULL,
  `groo` int DEFAULT NULL,
  `is_test_done` bit(1) DEFAULT NULL,
  `nickname` varchar(255) NOT NULL,
  `profile_image_file_name` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `social_id` bigint DEFAULT NULL,
  `repay_groo` int DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'2023-11-14 07:17:58.501174','2023-11-16 05:47:30.919749',2,1,65000,_binary '\0','dd','초기프로필.jpg','http://k.kakaocdn.net/dn/boyOhz/btqVQVJqiGr/dEga6Q3cA9fVkLh6u0R8e0/img_640x640.jpg',3160580715,0),(2,'2023-11-14 07:49:54.215965','2023-11-16 07:15:12.502445',26,0,75350,_binary '','바꿔야징','202311161246eed3-9d8e-448a-8fef-4e44dce77eb5','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311161246eed3-9d8e-448a-8fef-4e44dce77eb5',3162371307,0),(3,'2023-11-14 08:01:51.433581','2023-11-16 08:13:00.889675',0,0,80350,_binary '','임준수','20231115e424bda5-7c7b-40cc-9832-1d648434ea16','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231115e424bda5-7c7b-40cc-9832-1d648434ea16',3160641461,2835),(4,'2023-11-14 08:13:44.914853','2023-11-16 08:18:36.701782',4,0,301250,_binary '','프론트프론','초기프로필.jpg','http://k.kakaocdn.net/dn/bsVWEU/btsox9GS21C/r5q3uhxemKQ4MBSzcySdc1/img_640x640.jpg',3161893752,0),(5,'2023-11-14 15:00:23.859297','2023-11-16 08:18:36.553717',3,2,550,_binary '\0','양정훈','초기프로필.jpg','http://k.kakaocdn.net/dn/bT93C0/btrQcMS1lGF/00aJOENptm9ktGCY6qZb7K/img_640x640.jpg',3161869410,0),(6,'2023-11-14 15:02:35.663622','2023-11-16 06:53:04.088663',43,2,130900,_binary '','지현','20231116ae343832-d256-4225-a35a-e37f33211639','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231116ae343832-d256-4225-a35a-e37f33211639',3163104370,0);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-16 18:24:19
