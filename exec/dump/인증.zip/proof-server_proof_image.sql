-- MySQL dump 10.13  Distrib 5.7.38, for Win64 (x86_64)
--
-- Host: 3.35.137.30    Database: proof-server
-- ------------------------------------------------------
-- Server version	11.1.2-MariaDB-1:11.1.2+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proof_image`
--

DROP TABLE IF EXISTS `proof_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proof_image` (
  `proof_id` bigint(20) NOT NULL,
  `proof_image_id` bigint(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_url` varchar(255) NOT NULL,
  PRIMARY KEY (`proof_image_id`),
  KEY `FK63689r1ebyqn6rgdkun0s9ohy` (`proof_id`),
  CONSTRAINT `FK63689r1ebyqn6rgdkun0s9ohy` FOREIGN KEY (`proof_id`) REFERENCES `proof` (`proof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proof_image`
--

LOCK TABLES `proof_image` WRITE;
/*!40000 ALTER TABLE `proof_image` DISABLE KEYS */;
INSERT INTO `proof_image` VALUES (1,1,'2023111449cf143a-231f-47f2-a739-95658716c326','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023111449cf143a-231f-47f2-a739-95658716c326'),(2,2,'20231114db8dd6f3-5794-487c-8178-5530a2f7247a','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231114db8dd6f3-5794-487c-8178-5530a2f7247a'),(3,3,'202311149e301ac4-c012-47b5-9458-54f14d231375','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311149e301ac4-c012-47b5-9458-54f14d231375'),(4,4,'2023111419fbdfb2-0129-4214-9971-3d3a8b9471de','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023111419fbdfb2-0129-4214-9971-3d3a8b9471de'),(5,5,'20231114ca15c64c-0255-4655-9b95-746bbb803259','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231114ca15c64c-0255-4655-9b95-746bbb803259'),(8,8,'20231114ce41624f-ec20-48f0-ab20-1debc9ec6083','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231114ce41624f-ec20-48f0-ab20-1debc9ec6083'),(202,152,'20231115320237a4-8c2c-44e3-8550-50dacf13b579','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231115320237a4-8c2c-44e3-8550-50dacf13b579'),(203,153,'202311158125a9ec-37d4-44a9-a8e6-a7f798da6484','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311158125a9ec-37d4-44a9-a8e6-a7f798da6484'),(210,160,'20231115a15d0082-57fc-4521-ae9b-7ce6fc81e902','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231115a15d0082-57fc-4521-ae9b-7ce6fc81e902'),(211,161,'2023111535a5feeb-58a8-4c1a-ba5a-013241ecd285','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/2023111535a5feeb-58a8-4c1a-ba5a-013241ecd285'),(212,162,'20231115b9d53f3a-e00a-4312-904a-8aa8d2968997','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231115b9d53f3a-e00a-4312-904a-8aa8d2968997'),(213,163,'202311152e9d4ad3-312a-4677-a47d-32ec290a6633','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311152e9d4ad3-312a-4677-a47d-32ec290a6633'),(214,164,'202311155ddde4da-71c7-4928-bfac-1ef67a28959c','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311155ddde4da-71c7-4928-bfac-1ef67a28959c'),(215,165,'202311158c8bf53e-b1aa-4387-a66e-efeab2d72738','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311158c8bf53e-b1aa-4387-a66e-efeab2d72738'),(252,202,'202311164c239cee-ab10-4a91-9a40-3d7ab0b79033','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311164c239cee-ab10-4a91-9a40-3d7ab0b79033'),(303,253,'20231116f9eb4fe4-11dc-4412-9ad0-5a2078decc34','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231116f9eb4fe4-11dc-4412-9ad0-5a2078decc34'),(352,302,'202311166faa6a73-772b-4e44-ae24-59784c07c3d5','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/202311166faa6a73-772b-4e44-ae24-59784c07c3d5'),(353,303,'20231116a09a40c9-34ba-436b-890c-329845d55b1d','https://eokam-eara.s3.ap-northeast-2.amazonaws.com/20231116a09a40c9-34ba-436b-890c-329845d55b1d');
/*!40000 ALTER TABLE `proof_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17  0:09:46
